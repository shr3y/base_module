for(j=0;j<10;j++)
    alert(j);

